class Ending extends Phaser.Scene {

  constructor() {
    super({
      key: `ending`
    });
  }

  create() {

  }

  update() {
    this.handleInput();
  }

  handleInput() {

  }
}


